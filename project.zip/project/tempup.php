<?php
// Database connection
require('config.php'); // Include your database connection script

// Generate 150 unique mobile numbers starting from 6, 7, 8, or 9
$mobileNumbers = [];
$prefixes = ['6', '7', '8', '9'];

foreach ($prefixes as $prefix) {
    for ($i = 0; $i < 38; $i++) { // Adjust the loop limit to get a total of 150 numbers
        $randomNumber = mt_rand(100000000, 999999999); // Generate a random 9-digit number
        $mobileNumbers[] = $prefix . $randomNumber;
    }
}

// Shuffle the array to randomize the order of mobile numbers
shuffle($mobileNumbers);

// Prepare and execute the UPDATE query
$stmt = $link->prepare("UPDATE ce1voters SET MobileNumber = ? WHERE Sr = ?");
if ($stmt) {
    $sr = 1; // Start with Sr value 1
    foreach ($mobileNumbers as $mobileNumber) {
        $stmt->bind_param("ii", $mobileNumber, $sr);
        $stmt->execute();
        $sr++; // Increment Sr value for the next record
    }
    echo "Mobile numbers updated successfully.";
} else {
    echo "Error preparing statement: " . $link->error;
}

// Close statement and database connection
$stmt->close();
$link->close();
?>
