<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Introduction Website</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="body">
<header>
    <div class="container">
        <a href="home.html"><img class="logo" src="logo.jpg"></a>
        <h1 class="hover-4">ICT Voting Portal</h1>
        <nav>
            <ul>
                <li class="home"><a href="#">Sign Up</a></li>
                <li><a href="#">About</a></li>
            </li>
            <li style="float:right" class="about"><a href="#">Log Out</a></li>

            </ul>
        </nav>
    </div>
</header>



<center>    
    <div class="flex">
    <div class="slider">
        <div class="rotator">
          <div class="items">
            <img src="img4.jpeg"  >
          </div>
          <div class="items">
            <img src="img1.jpeg" >
          </div>
          <div class="items">
            <img src="img3.jpeg"  >
          </div>
          <div class="items">
            <img src="img4.jpeg" >
          </div>
        </div>
      </div>

      <div class="sloganarea">
        <h2 class="text">
            <img src="slogan2.jpeg" alt="">
        </h2>
      </div>
      <div>
        <img style="height: 350px;" src="slogan1.jpg">
      </div>

      </div>

      


  <div class="reg_form">

    <h2  style="font-family:Arial, Helvetica, sans-serif; font-size: xx-large;padding-top: 50px;">Registration Form</h2>

    

        <form  method="post">

          <label for="security">OTP:</label>
        <input type="text" id="security" name="otp" required placeholder="enter the otp for verification"><br><br><br>

        
        <a href="#" <input class="signup" type="submit" value="Sigh Up"><button class="signup">Sign Up</button></a>


        </form>

        
    

  </div>

</center>

<marquee class="marquee">The Election will be held only between 8 AM to 12 PM. So, hurry up and Represent Yourself!!!</marquee>
  
</body>
</html>

<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the entered OTP from the form
    $entered_otp = $_POST['otp'];

    // Retrieve the stored OTP from the hidden input field
    $stored_otp = $_POST['stored_otp']; // Assuming you stored it in a hidden input field

    // Check if the entered OTP matches the stored OTP
    if ($entered_otp == $stored_otp) {
        // OTP is verified, proceed with further actions
        // For example, redirect to the voting page
        header("Location: ce1_voting_page.php");
        exit;
    } else {
        // OTP doesn't match, redirect back to the form with an error message
        header("Location: vote_form.php?error=otp_mismatch");
        exit;
    }

}

?>