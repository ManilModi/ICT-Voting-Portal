<?php
    require('config.php'); // Assuming this file contains your database connection
echo"hello";
    if ($_SERVER["REQUEST_METHOD"] == "GET") {
        
        $entered_pwd = $_GET['pwd'];
        $entered_mobile = $_GET['MobileNumber'];
        
        // Establishing database connection
        
        // Escaping user inputs to prevent SQL injection
        $escaped_mobile = mysqli_real_escape_string($link, $entered_mobile);

        $sql = "SELECT pwd FROM ce2voters WHERE MobileNumber='$escaped_mobile'";
        $result = mysqli_query($link, $sql);

        if ($result) {
            // Checking if any rows are returned
            if (mysqli_num_rows($result) > 0) {
                // Fetching the row as an associative array
                $row = mysqli_fetch_assoc($result);
                // Comparing passwords
                if ($entered_pwd == $row['pwd']) {
                    // Redirecting to ce2_votingpage
                    
                    header("Location: ce2_votingpage.html");
                    exit();
                } else {
                    header("Location: vote_form.php?error=otp_mismatch");
                    exit();
                }
            } else {
                // No user found with the entered mobile number
                header("Location: vote_form.php?error=user_not_found");
                exit();
            }
        } else {
            // SQL query execution error
            echo "Error: " . $sql . "<br>" . mysqli_error($link);
        }

        // Closing database connection
        mysqli_close($link);
    }    
?>
