<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Introduction Website</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="body">
<header>
    
    <div class="container">
        <a href="home.html"><img class="logo" src="logo.jpg"></a>
        <h1 class="hover-4">ICT Voting Portal</h1>
        <nav>
            <ul>
                <div class="flex">
                    <div>
                <li class="home"><a href="home.html">SignUp</a></li>
                </div>
                <div>
                <li><a href="about_page.html">About</a></li>
                </div>
            </li>
            <div>
            <li style="float:right" class="about"><a href="home.html">LogOut</a></li>
            </div>
            </div>
            </ul>
        </nav>
    </div>
</header>



 
<center>
    
    <form class="signup" style="margin-top: 300px;" method="post">
            
        <h2 class="votinghead">GIVE YOUR VOTE TO THE FOLLOWING CANDIDATES OF CE THIRD YEAR</h2>
    
            <label for="vote">Rohit Patel</label>
            <input type="radio" id="vote" name="ce1" value="37">
            <br><br>

            <label for="vote">Anita Sharma</label>
            <input type="radio" id="vote" name="ce1" value="38">
            <br><br>

            <label for="vote">Amit Gupta</label>
            <input type="radio" id="vote" name="ce1" value="39">
            <br><br>

            <label for="vote">Kavita Singh</label>
            <input type="radio" id="vote" name="ce1" value="40">
            <br><br>

            <label for="vote">Nitin Mehta</label>
            <input type="radio" id="vote" name="ce1" value="41">
            <br><br>

            <label for="vote">Kumar Kumar</label>
            <input type="radio" id="vote" name="ce1" value="42">
            <br><br>
<br >

<input class="signup" type="submit" value="Vote" name="submit"><br><br>
            
          
          </form>
    </center>

<br><br>
<marquee class="marquee">The Election will be held only between 8 AM to 12 PM. So, hurry up and Represent Yourself!!!</marquee>
  
</body>
</html>

<?php
session_start();
$temp1 = base64_decode(urldecode($_GET['temp']));
$temp2 = base64_decode(urldecode($_GET['trialvf']));
$_SESSION['MobileNumber']=$temp1;
// $_SESSION['VotedFlag']=$temp2;
// $vf=""

echo $temp2;
if($temp2==0){

    if(isset($_POST['submit'])){
        if(isset($_POST['ce1'])){
            $_SESSION['vp']=$_POST['ce1'];
        $param1 = urlencode(base64_encode($_SESSION['MobileNumber']));
        $param2=urlencode(base64_encode($_SESSION['vp']));
                header("Location:thankyou_page.php?temp2=$param1&vf=$param2");
    
    }
    
    }

}else{
    echo "Dobara nai";
}

?>