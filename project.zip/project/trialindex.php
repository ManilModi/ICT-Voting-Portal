<?php

require('trial.php');

require('config.php');

$errors = [];
$inputs = [];

function sanitizeAndValidate($input, $filter, $name, $errorMessage) {
    global $errors, $inputs;
    
    $sanitizedInput = filter_var($input, $filter);
    $inputs['number'] = $sanitizedInput;
    
    if ($sanitizedInput == false || strlen($input) < 10) {
        $errors['number'] = $errorMessage;
        
    }
}

// Get the current time
$current_time = time();
echo $current_time;
// Example of another time to compare with (in this case, one hour from now)
$start_time =  1713827694;
$end_time =      1713910494;
// echo $current_time;
// Compare the two times
if ($current_time >= $start_time && $current_time <= $end_time) {
    $request_method = strtoupper($_SERVER['REQUEST_METHOD']);

if ($request_method === 'GET') {
    // show the form
    require('trialget.php');
} elseif ($request_method === 'POST') {
    
    $mobile_number = isset($_POST['number']) ? $_POST['number'] : '';
    // sanitizeAndValidate($mobile_number, FILTER_SANITIZE_NUMBER_INT, 'number', 'Please enter a Valid Mobile Number');

    global $errors, $inputs;
    
    $sanitizedInput = filter_var($mobile_number, FILTER_SANITIZE_NUMBER_INT);
    $inputs['number'] = $sanitizedInput;
    
    if ($sanitizedInput == false || strlen($mobile_number) < 10) {
        $errors['number'] = 'Please enter a Valid Mobile Number';
        
    }

    // if (strlen($mobile_number) < 10) {
    //     $errors['number'] = 'Mobile number must be of exactly 10 digits';
    // }

    if (count($errors) > 0) {
        require('trialget.php');
    }

    require('tempost.php');

    
    
}

require('trialfooter.php');
} else if($current_time<$start_time){
    header("location:beforetime.php");
}
else if($current_time > $end_time){
    header("location:resultcount.php");
    
}



