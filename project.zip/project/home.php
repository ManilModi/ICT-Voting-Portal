<?php

require_once "config.php";

// Infobip API credentials
$api_key = '2e68ed1198947e336289eb77653cc2ef-072df874-55b5-44f3-aeb9-05296cf37a51';
$sender_id = 'INFOBIP';

// Generate a random 6-digit OTP
$otp = mt_rand(100000, 999999);

// Store the OTP in the session or database for verification

// Send the OTP via SMS
$to_number = $_POST['MobileNumber']; // Assuming phone number is submitted via a form
$message = "Your OTP is: $otp";

$url = "https://api.infobip.com/sms/1/text/single";
$data = [
    "from" => $sender_id,
    "to" => $to_number,
    "text" => $message
];

$headers = [
    "Authorization: Basic " . base64_encode("apikey:$api_key"),
    "Content-Type: application/json",
    "Accept: application/json"
];

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$response = curl_exec($ch);
curl_close($ch);

// Display a form for OTP verification
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Introduction Website</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="body">
<header>
    <div class="container">
        <a href="home.html"><img class="logo" src="logo.jpg"></a>
        <h1 class="hover-4">ICT Voting Portal</h1>
        <nav>
            <ul>
                <li class="home"><a href="#">Sign Up</a></li>
                <li><a href="#">About</a></li>
            </li>
            <li style="float:right" class="about"><a href="#">Log Out</a></li>

            </ul>
        </nav>
    </div>
</header>



<center>    
    <div class="flex">
    <div class="slider">
        <div class="rotator">
          <div class="items">
            <img src="img4.jpeg"  >
          </div>
          <div class="items">
            <img src="img1.jpeg" >
          </div>
          <div class="items">
            <img src="img3.jpeg"  >
          </div>
          <div class="items">
            <img src="img4.jpeg" >
          </div>
        </div>
      </div>

      <div class="sloganarea">
        <h2 class="text">
            <img src="slogan2.jpeg" alt="">
        </h2>
      </div>
      <div>
        <img style="height: 350px;" src="slogan1.jpg">
      </div>

      </div>

      


  <div class="reg_form">

    <h2  style="font-family:Arial, Helvetica, sans-serif; font-size: xx-large;padding-top: 50px;">Registration Form</h2>

    <form  method="post">

        <label for="mobile">Mobile No.:</label>
        <input type="text" id="mobile" name="number" required placeholder="enter your registered number"><br><br><br>

        Select your Department:

        <input type="radio" id="ce" name="branch" value="ce">
        <label for="ce">CE</label>
        <input type="radio" id="ec" name="branch" value="ec">
        <label for="ec">EC</label>
        <input type="radio" id="it" name="branch" value="it">
        <label for="it">IT</label><br><br><br>

        Select your Academic Year:

        <input type="radio" id="1" name="year" value="first"  >
        <label for="1">First</label>
        <input type="radio" id="2" name="year" value="second">
        <label for="2">Second</label>
        <input type="radio" id="3" name="year" value="third">
        <label for="3">Third</label>
        <input type="radio" id="4" name="year" value="four">
        <label for="4">Fourth</label><br><br><br>

        <a href="#" <input class="signup" type="submit" value="Send OTP"><button class="signup">Send OTP</button></a><br><br>

        </form>

        <form method="post">

          <label for="security">OTP:</label>
        <input type="text" id="security" name="otp" required placeholder="enter the otp for verification"><br><br><br>

        
        <a href="#" <input class="signup" type="submit" value="Sigh Up"><button class="signup">Sign Up</button></a>


        </form>

        
    

  </div>

</center>

<marquee class="marquee">The Election will be held only between 8 AM to 12 PM. So, hurry up and Represent Yourself!!!</marquee>
  
</body>
</html>

