<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Thank you!!</title>
<link rel="stylesheet" href="thankyou_page.css">
</head>
<body class="bg">
<div class="c1">
<h2 class="fin"><pre>The Voting has not started yet
Please come After 8:00AM
The results will be declared tomorrow at 8:00 AM.
</pre></h2>
</div>
</body>
</html>