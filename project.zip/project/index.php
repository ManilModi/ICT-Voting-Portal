// Send an SMS using Twilio's REST API and PHP
<?php
// Required if your environment does not handle autoloading



require '"C:\xampp\htdocs\twilio-php-main\twilio-php-main\src\Twilio\autoload.php"';

// Your Account SID and Auth Token from console.twilio.com
$sid = "ACXXXXXX";
$token = "YYYYYY";
$client = new Twilio\Rest\Client($sid, $token);

// Use the Client to make requests to the Twilio REST API
$client->messages->create(
    // The number you'd like to send the message to
    '+917990370672',
    [
        // A Twilio phone number you purchased at https://console.twilio.com
        'from' => '+917990370672',
        // The body of the text message you'd like to send
        'body' => "Hey Jenny! Good luck on the bar exam!"
    ]
);