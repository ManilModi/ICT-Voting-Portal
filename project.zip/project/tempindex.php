<?php
// Get the current time
$current_time = time();
echo $current_time;
// Example of another time to compare with (in this case, one hour from now)
$start_time =  1713827694;
$end_time = 1714912400;
// echo $current_time;
// Compare the two times
if ($current_time >= $start_time && $current_time <= $end_time) {
    header("location:trialindex.php");
}else if($current_time<$start_time){
    header("location:beforetime.php");
}
else if($current_time > $end_time){
    header("location:resultcount.php");
    
}
?>