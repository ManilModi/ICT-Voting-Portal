<?php

session_start();

if ($result->num_rows > 0) {
        $api_key = '2e68ed1198947e336289eb77653cc2ef-072df874-55b5-44f3-aeb9-05296cf37a51'; // Get this from your config file
        $sender_id = 'ICT VOTING PORTAL';
        $otp = mt_rand(100000, 999999);

        // Store the OTP in a session variable
        $_SESSION['otp'] = $otp;

        $message = "Your OTP is: $otp";
        $url = "k2yjn8.api.infobip.com";
        $data = [
            "from" => $sender_id,
            "to" => $mobile_number,
            "text" => $message
        ];

        $headers = [
            "Authorization: Basic " . base64_encode("apikey:$api_key"),
            "Content-Type: application/json",
            "Accept: application/json"
        ];

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $response = curl_exec($ch);
        curl_close($ch);

        // Redirect to the OTP verification page
        header("Location: otp_verification.php");
        exit;
    } else {
        echo "Mobile number not found";
        header("Location: vote_form.php?error=form_not_submitted");
    exit;
    }



?>