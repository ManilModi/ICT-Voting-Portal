<?php


require('config.php');



function checkVoterEligibility($link, $mobile_number, $selected_branch, $selected_year, $selected_pwd)
{
    $table_name = strtolower("{$selected_branch}{$selected_year}voters");
    
    $mquery = "SELECT MobileNumber FROM {$table_name} WHERE MobileNumber = ?";
    $mstmt = mysqli_prepare($link, $mquery);
    mysqli_stmt_bind_param($mstmt, "s", $mobile_number);
    mysqli_stmt_execute($mstmt);
    $mresult = mysqli_stmt_get_result($mstmt);
    
    if (mysqli_num_rows($mresult) > 0) 
    {
        $pquery = "SELECT pwd, VotedFlag FROM {$table_name} WHERE MobileNumber = ?";
        $pstmt = mysqli_prepare($link, $pquery);
        mysqli_stmt_bind_param($pstmt, "s", $mobile_number);
        mysqli_stmt_execute($pstmt);
        $presult = mysqli_stmt_get_result($pstmt);
        
        if (mysqli_num_rows($presult) > 0) 
        {
            $row = mysqli_fetch_assoc($presult);
            $stored_pwd = $row['pwd'];
            $votedFlag = $row['VotedFlag'];
            
            if ($stored_pwd === $selected_pwd) 
            {

                if ($votedFlag != 0) {
                header("location:alreadyvoted.php");
                    
                    exit();
                }

                $uquery = "UPDATE {$table_name} SET SignUpFlag = 1 WHERE MobileNumber = ?";
                $ustmt = mysqli_prepare($link, $uquery);
                mysqli_stmt_bind_param($ustmt, "s", $mobile_number);
                
                if (mysqli_stmt_execute($ustmt)) 
                {
                    // Encode MobileNumber and VotedFlag
                    $t = urlencode(base64_encode($mobile_number));
                    $value1 = urlencode(base64_encode($votedFlag));

                    
                    
                    // Redirect to next file with encoded values as query parameters
                    header("location: {$table_name}_votingpage.php?temp=$t&trialvf=$value1");
                    exit();
                } 
                else {
                    echo "Error updating SignUpFlag: " . mysqli_error($link);
                    exit();
                }
            } 
            else {
                echo "Please enter a correct password";
                exit();
            }
        } 
        else {
            header("Location: vote_form.php?error=otp_mismatch");
            exit();
        }
    }
    else {
        echo "Mobile number not found in the '{$table_name}' list.";
        exit();
    }
}

session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $mobile_number = isset($_POST['number']) ? $_POST['number'] : '';
    $selected_branch = isset($_POST['branch']) ? $_POST['branch'] : '';
    $selected_year = isset($_POST['year']) ? $_POST['year'] : '';
    $selected_pwd = isset($_POST['pwd']) ? $_POST['pwd'] : '';
    
    switch ($selected_branch) {
        case 'CE':
        case 'EC':
        case 'IT':
            checkVoterEligibility($link, $mobile_number, $selected_branch, $selected_year, $selected_pwd);
            break;
        default:
            echo "Please select a branch!";
    }
}
?>
