<?php
// Set the start and end time of the election
$start_time = strtotime("2024-04-21 08:00:00"); // Election start time: April 22, 2024, 8:00 AM
$end_time = strtotime("2024-04-21 23:00:00");   // Election end time: April 22, 2024, 12:00 PM

$currentTime = timezone_location_get()
// Get the current time
// $current_time = time();

echo $currentTime;
// Check if the current time is within the election period
// if ($currentTime >= $start_time && $currentTime <= $end_time) {
//     // Election is ongoing, display the form
//     // include('election_form.php');
//     echo "ok";
// } else {
//     // Election is not ongoing, display a message or redirect to another page
//     echo "Sorry, the election is not currently ongoing.";
// }
?>
